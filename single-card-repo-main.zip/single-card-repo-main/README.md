# CPNT 260 - Web Page Construction

## Assignment 2 - Single Card

*Nicole Shukin*

 - [Card](https://l1ch3n.github.io/single-card-repo/)
 - [GitHub Page](https://github.com/l1ch3n/single-card-repo.git)

**Permission was granted in class to resubmit my 3pm today with no late deduction. Thanks Tony!**
